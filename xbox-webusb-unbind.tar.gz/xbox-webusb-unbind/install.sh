#!/usr/bin/env bash
# Installs the udev rule and handler script (works with any xpad-supported Xbox controller).
set -euo pipefail

if [ "$EUID" -ne 0 ]; then
    echo "Please run as root: sudo $0" >&2
    exit 1
fi

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

install -m 755 "$HERE/xbox-webusb-unbind.sh" /usr/local/bin/xbox-webusb-unbind.sh
install -m 644 "$HERE/90-xbox-webusb-unbind.rules" /etc/udev/rules.d/90-xbox-webusb-unbind.rules

# Remove files from the older single-device version (USB ID 045e:0b00), if present,
# so nothing runs twice.
rm -f /etc/udev/rules.d/50-usb-045e-0b00.rules
rm -f /etc/udev/rules.d/99-usb-045e-0b00.rules
rm -f /usr/local/bin/on-usb-045e-0b00.sh

udevadm control --reload-rules

echo "Installed:"
echo "  /usr/local/bin/xbox-webusb-unbind.sh"
echo "  /etc/udev/rules.d/90-xbox-webusb-unbind.rules"
echo
echo "Unplug and replug the controller to apply."
echo "Log: /var/log/xbox-webusb-unbind.log"
