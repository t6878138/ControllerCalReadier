#!/usr/bin/env bash
# Runs (as root) from udev for Xbox-style controllers.
#
# Normal mode (xpad bound an interface):
#   1) Makes the controller's USB device node accessible to normal users (for WebUSB).
#   2) After DELAY seconds, unbinds xpad from the interface, equivalent to:
#        echo "1-1:1.0" | sudo tee /sys/bus/usb/drivers/xpad/unbind
#      but with the interface name detected automatically.
#
# --perms-only mode (a Microsoft vendor-specific interface was added, xpad or not):
#   Only step 1. Used for controllers xpad doesn't claim, e.g. a 360 controller on a
#   Play & Charge cable (045e:028f).
set -u

PERMS_ONLY=0
if [ "${1:-}" = "--perms-only" ]; then
    PERMS_ONLY=1
    shift
fi
IFACE="${1:?usage: $0 [--perms-only] <usb-interface-kernel-name, e.g. 1-1:1.0>}"

# Seconds to wait after xpad binds before unbinding (change as needed).
DELAY=2.5

LOG=/var/log/xbox-webusb-unbind.log
XPAD=/sys/bus/usb/drivers/xpad
PAUSE_FILE=/etc/xbox-webusb-unbind.disabled   # create this file to pause the whole thing

log() { echo "$(date '+%F %T') $*" >> "$LOG"; }

if [ -e "$PAUSE_FILE" ]; then
    log "paused ($PAUSE_FILE exists); not touching $IFACE"
    exit 0
fi

DEV="${IFACE%%:*}"                      # "1-1:1.0" -> "1-1"
SYS="/sys/bus/usb/devices/$DEV"
VID=$(cat "$SYS/idVendor" 2>/dev/null || echo "????")
PID=$(cat "$SYS/idProduct" 2>/dev/null || echo "????")

if [ "$PERMS_ONLY" -eq 1 ]; then
    log "vendor-specific interface $IFACE added (device $DEV, USB ID $VID:$PID), permissions only"
else
    log "xpad bound $IFACE (device $DEV, USB ID $VID:$PID)"
fi

# Let normal users (and the browser) open the raw USB device node.
if [ -r "$SYS/busnum" ] && [ -r "$SYS/devnum" ]; then
    NODE=$(printf '/dev/bus/usb/%03d/%03d' "$(cat "$SYS/busnum")" "$(cat "$SYS/devnum")")
    if chmod 666 "$NODE"; then
        log "set $NODE to mode 666"
    else
        log "failed to chmod $NODE"
    fi
else
    log "could not find USB device node for $DEV"
fi

[ "$PERMS_ONLY" -eq 1 ] && exit 0

log "waiting ${DELAY}s before unbinding"
sleep "$DELAY"

if [ -e "$XPAD/$IFACE" ]; then
    if echo "$IFACE" > "$XPAD/unbind"; then
        log "unbound $IFACE from xpad"
    else
        log "failed to unbind $IFACE from xpad"
    fi
else
    log "$IFACE is no longer bound to xpad (unplugged?); nothing to do"
fi
