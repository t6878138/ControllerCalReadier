#!/usr/bin/env bash
# Removes the udev rule and handler script (and any files from the older version).
set -euo pipefail

if [ "$EUID" -ne 0 ]; then
    echo "Please run as root: sudo $0" >&2
    exit 1
fi

rm -f /etc/udev/rules.d/90-xbox-webusb-unbind.rules
rm -f /usr/local/bin/xbox-webusb-unbind.sh
rm -f /var/log/xbox-webusb-unbind.log
rm -f /etc/xbox-webusb-unbind.disabled

# Older single-device version (USB ID 045e:0b00), if present.
rm -f /etc/udev/rules.d/50-usb-045e-0b00.rules
rm -f /etc/udev/rules.d/99-usb-045e-0b00.rules
rm -f /usr/local/bin/on-usb-045e-0b00.sh
rm -f /var/log/usb-045e-0b00.log

udevadm control --reload-rules

echo "Removed the rule, script and logs."
echo "Unplug and replug the controller; xpad will keep it bound as a normal gamepad."
